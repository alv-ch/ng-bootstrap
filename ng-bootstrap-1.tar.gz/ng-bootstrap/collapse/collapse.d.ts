/**
 * A directive to provide a simple way of hiding and showing elements on the page.
 */
export declare class NgbCollapse {
    /**
     * If `true`, will collapse the element or show it otherwise.
     */
    collapsed: boolean;
}
