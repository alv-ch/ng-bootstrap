/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A configuration service for the [`NgbPagination`](#/components/pagination/api#NgbPagination) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the paginations used in the application.
 */
export class NgbPaginationConfig {
    constructor() {
        this.disabled = false;
        this.boundaryLinks = false;
        this.directionLinks = true;
        this.ellipses = true;
        this.maxSize = 0;
        this.pageSize = 10;
        this.rotate = false;
    }
}
NgbPaginationConfig.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ NgbPaginationConfig.ngInjectableDef = i0.defineInjectable({ factory: function NgbPaginationConfig_Factory() { return new NgbPaginationConfig(); }, token: NgbPaginationConfig, providedIn: "root" });
if (false) {
    /** @type {?} */
    NgbPaginationConfig.prototype.disabled;
    /** @type {?} */
    NgbPaginationConfig.prototype.boundaryLinks;
    /** @type {?} */
    NgbPaginationConfig.prototype.directionLinks;
    /** @type {?} */
    NgbPaginationConfig.prototype.ellipses;
    /** @type {?} */
    NgbPaginationConfig.prototype.maxSize;
    /** @type {?} */
    NgbPaginationConfig.prototype.pageSize;
    /** @type {?} */
    NgbPaginationConfig.prototype.rotate;
    /** @type {?} */
    NgbPaginationConfig.prototype.size;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnaW5hdGlvbi1jb25maWcuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcC8iLCJzb3VyY2VzIjpbInBhZ2luYXRpb24vcGFnaW5hdGlvbi1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxlQUFlLENBQUM7Ozs7Ozs7O0FBU3pDLE1BQU0sT0FBTyxtQkFBbUI7SUFEaEM7UUFFRSxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ2pCLGtCQUFhLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLG1CQUFjLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLGFBQVEsR0FBRyxJQUFJLENBQUM7UUFDaEIsWUFBTyxHQUFHLENBQUMsQ0FBQztRQUNaLGFBQVEsR0FBRyxFQUFFLENBQUM7UUFDZCxXQUFNLEdBQUcsS0FBSyxDQUFDO0tBRWhCOzs7WUFWQSxVQUFVLFNBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDOzs7OztJQUU5Qix1Q0FBaUI7O0lBQ2pCLDRDQUFzQjs7SUFDdEIsNkNBQXNCOztJQUN0Qix1Q0FBZ0I7O0lBQ2hCLHNDQUFZOztJQUNaLHVDQUFjOztJQUNkLHFDQUFlOztJQUNmLG1DQUFrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbi8qKlxuICogQSBjb25maWd1cmF0aW9uIHNlcnZpY2UgZm9yIHRoZSBbYE5nYlBhZ2luYXRpb25gXSgjL2NvbXBvbmVudHMvcGFnaW5hdGlvbi9hcGkjTmdiUGFnaW5hdGlvbikgY29tcG9uZW50LlxuICpcbiAqIFlvdSBjYW4gaW5qZWN0IHRoaXMgc2VydmljZSwgdHlwaWNhbGx5IGluIHlvdXIgcm9vdCBjb21wb25lbnQsIGFuZCBjdXN0b21pemUgdGhlIHZhbHVlcyBvZiBpdHMgcHJvcGVydGllcyBpblxuICogb3JkZXIgdG8gcHJvdmlkZSBkZWZhdWx0IHZhbHVlcyBmb3IgYWxsIHRoZSBwYWdpbmF0aW9ucyB1c2VkIGluIHRoZSBhcHBsaWNhdGlvbi5cbiAqL1xuQEluamVjdGFibGUoe3Byb3ZpZGVkSW46ICdyb290J30pXG5leHBvcnQgY2xhc3MgTmdiUGFnaW5hdGlvbkNvbmZpZyB7XG4gIGRpc2FibGVkID0gZmFsc2U7XG4gIGJvdW5kYXJ5TGlua3MgPSBmYWxzZTtcbiAgZGlyZWN0aW9uTGlua3MgPSB0cnVlO1xuICBlbGxpcHNlcyA9IHRydWU7XG4gIG1heFNpemUgPSAwO1xuICBwYWdlU2l6ZSA9IDEwO1xuICByb3RhdGUgPSBmYWxzZTtcbiAgc2l6ZTogJ3NtJyB8ICdsZyc7XG59XG4iXX0=